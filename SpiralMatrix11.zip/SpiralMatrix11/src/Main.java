import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        SpiralMatrix spiralMatrix = new SpiralMatrix();

        Scanner scanner = new Scanner(System.in);


        System.out.print("Enter the size of the matrix (n, 1 <= n <= 20): ");
        int n = scanner.nextInt();


        if (n < 1 || n > 20) {
            System.out.println("Invalid input! n must be between 1 and 20.");
            scanner.close();
            return;
        }


        System.out.println("Spiral Matrix for n = " + n + ":");
        int[][] matrix = spiralMatrix.generateMatrix(n);
        spiralMatrix.printMatrix(matrix);

        scanner.close();

    }
}